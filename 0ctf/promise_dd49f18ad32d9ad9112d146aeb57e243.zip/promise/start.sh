#!/bin/sh

service xinetd start
sleep infinity;
